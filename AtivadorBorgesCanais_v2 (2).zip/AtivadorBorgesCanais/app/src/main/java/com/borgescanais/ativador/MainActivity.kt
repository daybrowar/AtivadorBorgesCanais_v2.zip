package com.borgescanais.ativador

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.*
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {
    companion object {
        // Endereço do portal BORGES CANAIS
        const val API = "https://unitv-access-portal.lovable.app/api/public/installer/redeem"
        const val UNITV = "com.integration.unitvsiptv"
    }

    private lateinit var code: EditText
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var activate: Button
    private lateinit var open: Button
    private var pendingApk: File? = null
    private var pendingConfigs: List<Pair<String, String>> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        code = findViewById(R.id.code); status = findViewById(R.id.status)
        progress = findViewById(R.id.progress); activate = findViewById(R.id.activate)
        open = findViewById(R.id.open)
        code.addTextChangedListener(object : TextWatcher {
            var busy = false
            override fun afterTextChanged(s: Editable) {
                if (busy) return; busy = true
                val d = s.toString().filter { it.isDigit() }.take(11)
                val f = if (d.length > 4) d.substring(0, 4) + "-" + d.substring(4) else d
                s.replace(0, s.length, f); busy = false
            }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        activate.setOnClickListener { start() }
        open.setOnClickListener { openUnitv() }
    }

    override fun onResume() {
        super.onResume()
        // Ao voltar das telas de permissão, continua de onde parou
        if (pendingConfigs.isNotEmpty() && hasStorage()) thread { writeConfigs() }
        else if (pendingApk != null && canInstall()) installApk(pendingApk!!)
        if (isInstalled()) open.visibility = View.VISIBLE
    }

    private fun ui(msg: String, p: Int? = null) = runOnUiThread {
        status.text = msg
        if (p == null) progress.visibility = View.GONE
        else { progress.visibility = View.VISIBLE; progress.progress = p }
    }

    private fun start() {
        val c = code.text.toString().trim()
        if (c.length < 4) { ui("Digite o código completo."); return }
        activate.isEnabled = false
        thread {
            try {
                ui("Validando código...", 0)
                val conn = URL(API).openConnection() as HttpURLConnection
                conn.requestMethod = "POST"; conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json")
                conn.outputStream.use { it.write(JSONObject().put("code", c).toString().toByteArray()) }
                if (conn.responseCode != 200) {
                    ui("Código inválido ou já utilizado."); runOnUiThread { activate.isEnabled = true }; return@thread
                }
                val json = JSONObject(conn.inputStream.bufferedReader().readText())
                val files = json.getJSONArray("files")
                var apkUrl: String? = null
                val configs = mutableListOf<Pair<String, String>>()
                for (i in 0 until files.length()) {
                    val f = files.getJSONObject(i)
                    if (f.getString("slot") == "apk") apkUrl = f.getString("url")
                    else configs += f.getString("file_name") to f.getString("url")
                }
                // 1) Baixa os arquivos de configuração para o cache
                val cached = configs.mapIndexed { i, (name, url) ->
                    val out = File(cacheDir, "cfg/$name"); out.parentFile?.mkdirs()
                    download(url, out, "Baixando arquivo ${i + 1} de ${configs.size}")
                    name to out.absolutePath
                }
                pendingConfigs = cached
                // 2) Baixa o app
                if (apkUrl != null) {
                    val apk = File(cacheDir, "apk/unitvfree.apk"); apk.parentFile?.mkdirs()
                    download(apkUrl, apk, "Baixando Unit TV Free")
                    pendingApk = apk
                }
                runOnUiThread { continueFlow() }
            } catch (e: Exception) {
                ui("Falha de conexão. Verifique a internet e tente de novo.")
                runOnUiThread { activate.isEnabled = true }
            }
        }
    }

    private fun download(url: String, out: File, label: String) {
        val conn = URL(url).openConnection() as HttpURLConnection
        val total = conn.contentLengthLong
        conn.inputStream.use { input -> out.outputStream().use { o ->
            val buf = ByteArray(64 * 1024); var read: Int; var done = 0L
            while (input.read(buf).also { read = it } != -1) {
                o.write(buf, 0, read); done += read
                if (total > 0) ui("$label...", (done * 100 / total).toInt())
            }
        } }
    }

    private fun continueFlow() {
        if (pendingConfigs.isNotEmpty()) {
            if (!hasStorage()) { askStorage(); return }
            thread { writeConfigs() }; return
        }
        pendingApk?.let { if (!canInstall()) askInstall() else installApk(it) }
    }

    private fun writeConfigs() {
        try {
            val dir = File(Environment.getExternalStorageDirectory(), "Android"); dir.mkdirs()
            for ((name, path) in pendingConfigs) File(path).copyTo(File(dir, name), overwrite = true)
            pendingConfigs = emptyList()
            ui("Arquivos copiados para a pasta Android ✓")
            runOnUiThread { continueFlow() }
        } catch (e: Exception) { ui("Não foi possível copiar os arquivos: ${e.message}") }
    }

    private fun hasStorage(): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == 0 || Build.VERSION.SDK_INT < 23

    private fun askStorage() {
        ui("Permita o acesso ao armazenamento para copiar os arquivos.")
        if (Build.VERSION.SDK_INT >= 30) {
            try { startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))) }
            catch (e: Exception) { startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)) }
        } else if (Build.VERSION.SDK_INT >= 23) {
            requestPermissions(arrayOf(android.Manifest.permission.WRITE_EXTERNAL_STORAGE), 1)
        }
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) { if (hasStorage()) continueFlow() }

    private fun canInstall() = Build.VERSION.SDK_INT < 26 || packageManager.canRequestPackageInstalls()

    private fun askInstall() {
        ui("Autorize instalar apps deste ativador e volte aqui.")
        startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName")))
    }

    private fun installApk(apk: File) {
        pendingApk = null
        ui("Toque em INSTALAR na próxima tela.")
        val uri = FileProvider.getUriForFile(this, "$packageName.files", apk)
        startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
        open.visibility = View.VISIBLE
    }

    private fun isInstalled() = try { packageManager.getPackageInfo(UNITV, 0); true } catch (e: Exception) { false }

    private fun openUnitv() {
        val i = packageManager.getLaunchIntentForPackage(UNITV) ?: packageManager.getLeanbackLaunchIntentForPackage(UNITV)
        if (i != null) startActivity(i) else Toast.makeText(this, "Conclua a instalação do Unit TV Free primeiro.", Toast.LENGTH_LONG).show()
    }
}
